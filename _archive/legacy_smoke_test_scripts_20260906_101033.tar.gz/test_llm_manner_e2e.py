from __future__ import annotations
import argparse, sys, os, time
BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                    "stagecap_robosuite_libero_repro_20260714")
sys.path.insert(0, BASE)
import numpy as np

TEST_CASES = [
    ("像捧着装满水的玻璃杯，轻轻把方块放到目标位置上", "gentle"),
    ("小心翣翣，像在排除炸弹一样慢慢靠近", "ultra_careful"),
    ("像哄婴儿睡觉一样，极其轻柔缓慢地拿起方块", "ultra_gentle"),
    ("正常操作就行，随便", "normal"),
    ("迅速抓起来，越快越好", "fast"),
    ("用力把它压进去，确保固定住不会松动", "firm"),
    ("先快速靠近，到最后5厘米时慢慢轻触", "fast_then_slow"),
    ("Place the block gently onto the platform", "gentle_en"),
    ("Grab it as fast as possible", "fast_en"),
]
MOCK_SPECS = [
    dict(max_joint_vel=0.04, kp_max=400.0, grip_fraction_max=0.3, max_jerk=0.8, label="mock_gentle"),
    dict(max_joint_vel=0.02, kp_max=300.0, grip_fraction_max=0.2, max_jerk=0.5, label="mock_ultra"),
    dict(max_joint_vel=0.02, kp_max=280.0, grip_fraction_max=0.15, max_jerk=0.5, label="mock_baby"),
    dict(label="mock_normal"),
    dict(min_joint_vel=0.30, label="mock_fast"),
    dict(kp_min=1200.0, grip_fraction_min=0.85, label="mock_firm"),
    dict(max_joint_vel=0.06, kp_max=500.0, max_jerk=2.0, label="mock_mixed"),
    dict(max_joint_vel=0.04, kp_max=380.0, grip_fraction_max=0.3, label="mock_gentle_en"),
    dict(min_joint_vel=0.28, label="mock_fast_en"),
]
def spec_to_exec(spec):
    v = spec.max_joint_vel
    vmin = spec.min_joint_vel
    if v is not None and vmin is not None: v_max = (v*0.85+vmin*1.05)/2
    elif v is not None: v_max = v*0.85
    elif vmin is not None: v_max = vmin*1.10
    else: v_max = 0.12
    a_max = max(0.01, v_max*0.7)
    k = spec.kp_max; km = spec.kp_min
    if k and km: kp = (k*0.85+km*1.05)/2
    elif k: kp = k*0.85
    elif km: kp = km*1.10
    else: kp = 1000.0
    g = spec.grip_fraction_max; gm = spec.grip_fraction_min
    if g and gm: grip = (g*0.9+gm*1.05)/2
    elif g: grip = g*0.90
    elif gm: grip = min(1.0, gm*1.10)
    else: grip = 0.88
    grip = max(0.35, grip)
    return dict(v_max=float(v_max), a_max=float(a_max),
                jerk=spec.max_jerk, kp=float(kp), grip=float(grip))

def run_lift(env, api, p):
    cp, _, _ = api.get_object_pose("red cube")
    quat = np.array([0.0, 0.0, 1.0, 0.0])
    ap = cp.copy(); ap[2] += 0.20
    api.goto_pose_with_profile(ap, quat, v_max=p["v_max"], a_max=p["a_max"], jerk_limit=p["jerk"])
    for _ in range(8): env._step_once()
    api.set_impedance_stiffness(kp_pos=p["kp"])
    gp = cp.copy(); gp[2] += 0.002
    api.goto_pose_with_profile(gp, quat, v_max=max(0.02,p["v_max"]*0.6),
                               a_max=max(0.01,p["a_max"]*0.5), jerk_limit=p["jerk"])
    for _ in range(5): env._step_once()
    api.close_gripper_partial(force=p["grip"], steps=50)
    api.set_impedance_stiffness(kp_pos=1000.0)
    lp = gp.copy(); lp[2] += 0.18
    api.goto_pose_with_profile(lp, quat, v_max=p["v_max"], a_max=p["a_max"], jerk_limit=p["jerk"])
    for _ in range(10): env._step_once()
    cp2, _, _ = api.get_object_pose("red cube")
    return dict(reward=float(env.compute_reward()), dz=float(cp2[2]-cp[2]))

def main():
    pa = argparse.ArgumentParser()
    pa.add_argument("--mock-llm", action="store_true")
    pa.add_argument("--no-validator", action="store_true")
    pa.add_argument("--seed", type=int, default=42)
    args = pa.parse_args()
    from capx.envs.simulators.robosuite_cube_lift import FrankaRobosuiteCubeLiftLowLevel
    from capx.integrations.franka.control_privileged import FrankaControlPrivilegedApi
    from capx.envs.manner_validator import MannerValidator, MannerSpec
    import capx.envs.manner_validator as _mv
    StageStatus = _mv.StageStatus
    if not args.mock_llm:
        from capx.llm.manner_parser import LLMMannerParser
        parser = LLMMannerParser()
        print("[LLM] Gemini 3.7 Flash OK")
    else:
        parser = None; print("[LLM] mock mode")
    print("[ENV] init...")
    env = FrankaRobosuiteCubeLiftLowLevel(privileged=True, enable_render=False, max_steps=8000, seed=args.seed)
    api = FrankaControlPrivilegedApi(env)
    validator = MannerValidator()
    print("[ENV] ready")
    results = []
    SEP = "=" * 65
    print(SEP)
    print("  E2E: NL -> MannerSpec -> execute -> dual-criterion check")
    print(SEP)
    for idx, (prompt, tag) in enumerate(TEST_CASES):
        print("")
        print(f"[{idx+1:02d}/{len(TEST_CASES):02d}] [{tag}]  {prompt[:50]}")
        t0 = time.time()
        try:
            if args.mock_llm:
                kw = MOCK_SPECS[idx % len(MOCK_SPECS)]
                flds = ["max_joint_vel","min_joint_vel","kp_max","kp_min",
                        "grip_fraction_max","grip_fraction_min","max_jerk","label"]
                spec = MannerSpec(**{k: kw.get(k) for k in flds if kw.get(k) is not None})
                reason = f"[mock] {spec.label}"
            else:
                spec, reason = parser.parse_with_reasoning(prompt)
        except Exception as e:
            print(f"  LLM FAIL: {e}")
            results.append(dict(tag=tag, label="ERROR", task_ok=None, manner_ok=None))
            continue
        print(f"  parse: {spec.label}  vel_max={spec.max_joint_vel}  kp_max={spec.kp_max}  grip_max={spec.grip_fraction_max}  jerk={spec.max_jerk}  [{time.time()-t0:.1f}s]")
        p = spec_to_exec(spec)
        print(f"  exec:  v={p['v_max']:.3f} a={p['a_max']:.3f} kp={p['kp']:.0f} grip={p['grip']:.2f}")
        env.reset(seed=args.seed)
        env.begin_manner_recording(clear=True)
        t1 = time.time()
        try:
            res = run_lift(env, api, p)
        except Exception as e:
            print(f"  EXEC FAIL: {e}")
            results.append(dict(tag=tag, label=spec.label, task_ok=False, manner_ok=None))
            continue
        task_ok = res["reward"] >= 0.95
        print(f"  task:  reward={res['reward']:.3f} dz={res['dz']*100:.1f}cm  [{'OK' if task_ok else 'FAIL'}]  [{time.time()-t1:.1f}s]")
        manner_ok = None
        if not args.no_validator:
            tel = env.get_manner_telemetry()
            if tel:
                ev = validator.validate(tel, spec)
                manner_ok = (ev.status == StageStatus.SATISFIED)
                vi = "" if manner_ok else ("  " + (ev.rationale or "").split(chr(10))[0][:120])
                print(f"  manner: steps={len(tel)}  [{'OK' if manner_ok else 'FAIL'}]{vi}")
            else:
                print("  manner: no telemetry")
        results.append(dict(tag=tag, label=spec.label, task_ok=task_ok, manner_ok=manner_ok))
    env.close()
    print("")
    print(SEP)
    print(f"  {chr(35):>3}  {chr(116)+chr(97)+chr(103):<14}  {chr(108)+chr(97)+chr(98)+chr(101)+chr(108):<17}  task  manner  both")
    print("-" * 65)
    n_task = n_manner = n_both = n_total = 0
    for i, r in enumerate(results):
        ts = "OK" if r["task_ok"] else ("FAIL" if r["task_ok"] is False else "?")
        ms = "OK" if r["manner_ok"] else ("FAIL" if r["manner_ok"] is False else "?")
        bs = "OK" if (r["task_ok"] and r["manner_ok"]) else ("?" if None in [r["task_ok"],r["manner_ok"]] else "FAIL")
        print(f"  {i+1:>3}.  {r['tag']:<14}  {r['label']:<17}  {ts:^4}  {ms:^6}  {bs:^4}")
        if r["task_ok"] is not None:
            n_total += 1
            if r["task_ok"]: n_task += 1
            if r["manner_ok"]: n_manner += 1
            if r["task_ok"] and r["manner_ok"]: n_both += 1
    print(SEP)
    if n_total:
        print(f"  task_success_rate:   {n_task}/{n_total}  ({100*n_task/n_total:.0f}%)")
        print(f"  manner_comply_rate:  {n_manner}/{n_total}  ({100*n_manner/n_total:.0f}%)")
        print(f"  dual_pass_rate:      {n_both}/{n_total}  ({100*n_both/n_total:.0f}%)")
    print("")
    print("  dual_pass = truly understanding the NL instruction")
    return 0 if n_both == n_total and n_total > 0 else 1

if __name__ == "__main__":
    sys.exit(main())
