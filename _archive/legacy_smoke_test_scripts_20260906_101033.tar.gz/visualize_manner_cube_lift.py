"""
MannerCap Cube Lifting — 轨迹可视化
对比三种 manner 的速度剖面、EEF 高度、夹爪宽度、关节刚度
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.gridspec import GridSpec

PRESETS = {
    "slowly_gently": dict(
        label="slowly + gently\n(缓缓靠近 + 轻柔夹持)",
        color="#3b82f6",
        approach_v_max=0.04, approach_a_max=0.02, approach_jerk=None,
        descend_v_max=0.03,  descend_a_max=0.10,  descend_jerk=0.8,
        grasp_kp=450,        grip_force=0.75,
        lift_v_max=0.04,     lift_a_max=0.10,     lift_jerk=0.8,
    ),
    "normal": dict(
        label="normal\n(常规操作)",
        color="#10b981",
        approach_v_max=0.12, approach_a_max=0.15, approach_jerk=None,
        descend_v_max=0.10,  descend_a_max=0.15,  descend_jerk=None,
        grasp_kp=900,        grip_force=0.90,
        lift_v_max=0.12,     lift_a_max=0.15,     lift_jerk=None,
    ),
    "fast": dict(
        label="fast\n(快速抓取)",
        color="#ef4444",
        approach_v_max=0.30, approach_a_max=0.50, approach_jerk=None,
        descend_v_max=0.25,  descend_a_max=0.50,  descend_jerk=None,
        grasp_kp=1500,       grip_force=1.00,
        lift_v_max=0.30,     lift_a_max=0.50,     lift_jerk=None,
    ),
}

DT = 0.05
DEFAULT_KP = 1500.0
Z_ABOVE = 0.11; Z_GRASP = -0.09; Z_LIFT = 0.09
DIST_APPROACH = 1.20; DIST_DESCEND = 1.60; DIST_LIFT = 1.60

def _trap(distance, v_max, a_max, dt=DT):
    if distance < 1e-8: return np.array([0.0])
    t_acc = v_max / a_max
    d_acc = 0.5 * a_max * t_acc**2
    if 2*d_acc > distance:
        t_acc = np.sqrt(distance / a_max)
        v_peak = a_max * t_acc; T = 2*t_acc
    else:
        v_peak = v_max; t_cruise = (distance - 2*d_acc)/v_max; T = 2*t_acc + t_cruise
    ts = np.arange(0, T+dt, dt); vels = []
    for t in ts:
        if t <= t_acc: vels.append(a_max*t)
        elif t <= T-t_acc: vels.append(v_peak)
        else: vels.append(max(a_max*(T-t), 0))
    return np.array(vels)

def _quintic(distance, v_max, dt=DT):
    if distance < 1e-8: return np.array([0.0])
    T = 7.5 * distance / v_max; T = max(T, dt*3)
    ts = np.arange(0, T+dt, dt); vels = []
    for t in ts:
        s = t/T
        vels.append(distance * (30*s**2 - 60*s**3 + 30*s**4) / T)
    return np.array(vels)

def sim_phase(dist, v_max, a_max, jerk):
    return _quintic(dist, v_max) if jerk is not None else _trap(dist, v_max, a_max)

def build(p):
    v1 = sim_phase(DIST_APPROACH, p["approach_v_max"], p["approach_a_max"], p["approach_jerk"])
    v2 = np.array([0.0])
    v3 = sim_phase(DIST_DESCEND,  p["descend_v_max"],  p["descend_a_max"],  p["descend_jerk"])
    steps_grip = 60
    v4 = np.zeros(steps_grip)
    v5 = sim_phase(DIST_LIFT,     p["lift_v_max"],     p["lift_a_max"],     p["lift_jerk"])

    vels = np.concatenate([v1,v2,v3,v4,v5])
    n = len(vels)
    zs = np.empty(n)
    cur = 0
    for seg, (za,zb) in zip([v1,v2,v3,v4,v5],
                              [(0.20,Z_ABOVE),(Z_ABOVE,Z_ABOVE),(Z_ABOVE,Z_GRASP),
                               (Z_GRASP,Z_GRASP),(Z_GRASP,Z_LIFT)]):
        ns = len(seg); zs[cur:cur+ns] = np.linspace(za,zb,ns); cur+=ns

    gripper = np.full(n, 40.0)
    gs = len(v1)+len(v2)+len(v3)
    frac = 1.0 - p["grip_force"]; target = 40.0*frac
    gripper[gs:gs+steps_grip] = np.linspace(40.0, target, steps_grip)
    gripper[gs+steps_grip:] = target

    kp = np.full(n, DEFAULT_KP); kp[len(v1):] = p["grasp_kp"]
    ts = np.arange(n)*DT
    bps = [len(v1), len(v1)+len(v2), len(v1)+len(v2)+len(v3), len(v1)+len(v2)+len(v3)+steps_grip]
    return ts, vels, zs, gripper, kp, bps

preset_keys = ["slowly_gently","normal","fast"]
all_data = {k: build(PRESETS[k]) for k in preset_keys}
t_max = max(d[0][-1] for d in all_data.values())

AXES_BG="#1e293b"; GRID="#334155"; TC="#e2e8f0"; AC="#475569"
PHASE_C=["#dbeafe","#fef9c3","#dcfce7","#fce7f3","#ede9fe"]
PHASE_N=["approach\n靠近","set kp","descend\n降落","grip\n夹持","lift\n提升"]

fig = plt.figure(figsize=(16,12))
fig.patch.set_facecolor("#0f172a")
gs_layout = GridSpec(4,3,figure=fig,hspace=0.55,wspace=0.38,top=0.90,bottom=0.07,left=0.07,right=0.97)

row_ylims = [(-0.20,0.30),(None,None),(0,50),(100,1800)]
row_ylabels = ["Z (m)","vel (rad/s)","width (mm)","kp"]

for col,key in enumerate(preset_keys):
    p = PRESETS[key]; ts,vels,zs,gripper,kp,bps = all_data[key]; c = p["color"]
    phase_t = [0]+[ts[b] if b<len(ts) else ts[-1] for b in bps]+[ts[-1]]

    for row in range(4):
        ax = fig.add_subplot(gs_layout[row,col])
        ax.set_facecolor(AXES_BG)
        ax.tick_params(colors=TC,labelsize=7)
        for sp in ax.spines.values(): sp.set_edgecolor(AC)
        ax.grid(True,color=GRID,linewidth=0.5,alpha=0.7)
        ax.set_xlim(0,t_max*1.02)

        for i in range(5):
            ax.axvspan(phase_t[i],phase_t[i+1],alpha=0.10,color=PHASE_C[i],zorder=0)
        for bp in bps:
            if bp<len(ts): ax.axvline(ts[bp],color=AC,linewidth=0.8,linestyle="--",alpha=0.6)

        if row==0:
            ax.plot(ts,zs,color=c,linewidth=2.0)
            ax.axhline(0,color="#64748b",linewidth=0.5,linestyle=":")
            ax.set_ylim(-0.20,0.30)
            if col==0:
                for i,nm in enumerate(PHASE_N):
                    ax.text((phase_t[i]+phase_t[i+1])/2,0.27,nm,ha="center",va="top",fontsize=5.5,color=TC,alpha=0.8)
        elif row==1:
            ax.plot(ts,vels,color=c,linewidth=2.0)
            vmax_val = max(p["approach_v_max"],p["descend_v_max"],p["lift_v_max"])
            ax.axhline(vmax_val,color=c,linewidth=0.8,linestyle=":",alpha=0.5)
            ax.text(t_max*0.02,vmax_val*1.08,f"v_max={vmax_val}",fontsize=6.5,color=c,alpha=0.9)
            ax.set_ylim(0,None)
        elif row==2:
            ax.plot(ts,gripper,color=c,linewidth=2.0)
            ax.fill_between(ts,gripper,alpha=0.15,color=c)
            ax.set_ylim(0,50)
            fw=gripper[-1]; ax.text(ts[-1]*0.97,fw+2,f"{fw:.0f}mm",ha="right",fontsize=7,color=c)
        elif row==3:
            ax.step(ts,kp,color=c,linewidth=2.0,where="post")
            ax.fill_between(ts,kp,200,alpha=0.10,color=c,step="post")
            ax.set_ylim(100,1800)
            ax.text(ts[-1]*0.97,p["grasp_kp"]+40,f"kp={p['grasp_kp']}",ha="right",fontsize=7,color=c)
            ax.set_xlabel("t (s)",color=TC,fontsize=8)

        ax.set_ylabel(row_ylabels[row],color=TC,fontsize=8)

    ttl = p["label"]; total_t = ts[-1]
    fig.text(0.155+col*0.30,0.93,ttl,ha="center",va="center",fontsize=10,color=c,fontweight="bold")
    fig.text(0.155+col*0.30,0.915,f"总时长 {total_t:.1f}s  |  {len(ts)} steps",ha="center",va="center",fontsize=8,color=TC,alpha=0.75)

fig.text(0.5,0.975,"MannerCap — RoboSuite Cube Lifting 轨迹对比",ha="center",fontsize=14,color="white",fontweight="bold")
fig.text(0.5,0.957,"四维物理约束层：A(速度剖面)  B(阻抗刚度)  C(夹持力)  D(急动度限制)",ha="center",fontsize=9,color="#94a3b8")

handles=[mpatches.Patch(color=PRESETS[k]["color"],label=PRESETS[k]["label"].replace("\n"," ")) for k in preset_keys]
fig.legend(handles=handles,loc="lower center",ncol=3,framealpha=0.2,facecolor="#1e293b",edgecolor=AC,labelcolor=TC,fontsize=9,bbox_to_anchor=(0.5,0.005))

out = "/workdata/stage_cap_privileged_data_generation_repro_20260629/robosuite/stagecap_robosuite_libero_repro_20260714/new/manner_cube_lift_visualization.png"
plt.savefig(out,dpi=150,bbox_inches="tight",facecolor=fig.get_facecolor())
plt.close()

print("=" * 60)
for key in preset_keys:
    ts,vels,zs,gripper,kp,_ = all_data[key]; p = PRESETS[key]
    print(f"[{key}]  总时长={ts[-1]:.1f}s  峰值速度={vels.max():.4f} rad/s  夹爪={gripper[-1]:.0f}mm  kp={p['grasp_kp']}")
slow_t = all_data["slowly_gently"][0][-1]; fast_t = all_data["fast"][0][-1]
print(f"\n速度比 fast/slowly_gently = {slow_t/fast_t:.1f}x")
print(f"图像已保存: {out}")
