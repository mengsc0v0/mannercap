"""
MannerCap 四维物理约束可视化验证
自包含脚本——直接内联辅助函数，无需加载仿真环境。
输出: manner_trajectory_verification.png
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

# ────────────────────────────────────────────────────────────────────────────
# 内联辅助函数（与 robosuite_base.py / libero.py 中完全相同的实现）
# ────────────────────────────────────────────────────────────────────────────
def _trapezoid_waypoints(q_start, q_end, distance, T, t_acc, v_max, a_max, dt):
    """梯形速度剖面轨迹点（Manner A: 速度约束）"""
    direction = (q_end - q_start) / distance
    n_steps = max(1, int(np.ceil(T / dt)))
    waypoints = []
    for i in range(1, n_steps + 1):
        t = min(i * dt, T)
        if t <= t_acc:
            s = 0.5 * a_max * t ** 2
        elif t <= T - t_acc:
            s = 0.5 * a_max * t_acc ** 2 + v_max * (t - t_acc)
        else:
            t_dec = T - t
            s = distance - 0.5 * a_max * t_dec ** 2
        s = float(np.clip(s, 0.0, distance))
        waypoints.append(q_start + direction * s)
    return waypoints


def _quintic_waypoints(q_start, q_end, T, dt):
    """五次多项式最小抖动轨迹点（Manner D: 平稳约束）"""
    n_steps = max(1, int(np.ceil(T / dt)))
    waypoints = []
    for i in range(1, n_steps + 1):
        s = min(i * dt / T, 1.0)
        blend = 10.0 * s ** 3 - 15.0 * s ** 4 + 6.0 * s ** 5
        waypoints.append(q_start + (q_end - q_start) * blend)
    return waypoints

# ────────────────────────────────────────────────────────────────────────────
# 测试参数
# ────────────────────────────────────────────────────────────────────────────
SIM_FREQ = 20.0
DT = 1.0 / SIM_FREQ
Q_START = np.array([0.0])
Q_END   = np.array([1.2])   # 1.2 rad 关节运动
DISTANCE = float(np.linalg.norm(Q_END - Q_START))

# Manner A/D 场景
scenarios = [
    ("迅速移动\nv_max=0.25", "#e74c3c", 0.25, 0.20, None),
    ("正常速度\nv_max=0.15", "#3498db", 0.15, 0.10, None),
    ("缓缓靠近\nv_max=0.05", "#2ecc71", 0.05, 0.03, None),
    ("平稳放下\n(quintic)",   "#9b59b6", 0.08, 0.05, 0.8),
]

def make_profile(v_max, a_max, jerk_limit):
    if jerk_limit is not None:
        t_jerk = (60.0 * DISTANCE / max(jerk_limit, 1e-6)) ** (1.0 / 3.0)
        t_vel  = 15.0 * DISTANCE / (8.0 * max(v_max, 1e-6))
        T = max(t_jerk, t_vel, DT)
        wpts = _quintic_waypoints(Q_START, Q_END, T, DT)
    else:
        t_acc = v_max / max(a_max, 1e-6)
        d_acc = 0.5 * a_max * t_acc ** 2
        if 2.0 * d_acc >= DISTANCE:
            t_acc = np.sqrt(DISTANCE / max(a_max, 1e-6))
            T = 2.0 * t_acc
        else:
            T = 2.0 * t_acc + (DISTANCE - 2.0 * d_acc) / max(v_max, 1e-6)
        T = max(T, DT)
        wpts = _trapezoid_waypoints(Q_START, Q_END, DISTANCE, T, t_acc, v_max, a_max, DT)
    pos = np.array([Q_START[0]] + [w[0] for w in wpts])
    t   = np.arange(len(pos)) * DT
    vel = np.gradient(pos, DT)
    acc = np.gradient(vel, DT)
    jrk = np.gradient(acc, DT)
    return t, pos, vel, acc, jrk

profiles = [make_profile(vm, am, jl) for (_, _, vm, am, jl) in scenarios]

# Manner C: 夹爪场景
GRIPPER_MAX = 0.08
gripper_scenes = [
    ("虚握\nforce=0.10",  "#f1c40f", 0.10),
    ("轻捏\nforce=0.30",  "#e67e22", 0.30),
    ("正常\nforce=0.60",  "#3498db", 0.60),
    ("紧握\nforce=0.95",  "#e74c3c", 0.95),
]
gripper_gaps = [(1.0 - f) * GRIPPER_MAX * 2 * 1000 for (_, _, f) in gripper_scenes]

# Manner B: 刚度场景（模拟接触力响应）
stiff_scenes = [
    ("轻轻接触\nkp=400",   "#2ecc71",  400, 0.8),
    ("正常操作\nkp=1000",  "#3498db", 1000, 2.0),
    ("用力按压\nkp=1500",  "#e74c3c", 1500, 3.0),
]
# 模拟接触时的力响应曲线：F = kp * (x_target - x_actual)
t_contact = np.linspace(0, 0.5, 100)
x_intrusion = 0.002 * np.sin(np.linspace(0, np.pi, 100))  # 0-2mm 形变
contact_forces = {s[0]: s[2] * x_intrusion for s in stiff_scenes}

# ────────────────────────────────────────────────────────────────────────────
# 绘图
# ────────────────────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(19, 14), facecolor="#0f1117")
fig.suptitle(
    "MannerCap 四维物理约束验证  ·  Manner-Aware Trajectory Constraint Verification",
    fontsize=15, fontweight="bold", color="white", y=0.99,
)

gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.50, wspace=0.36,
                       top=0.95, bottom=0.05, left=0.07, right=0.97)

BG = "#161b27"; AX = "#d0d0d0"; GD = "#252535"

def style(ax, title, xl="", yl=""):
    ax.set_facecolor(BG)
    ax.spines[:].set_color("#3a3a5a")
    ax.tick_params(colors=AX, labelsize=8)
    ax.xaxis.label.set_color(AX); ax.yaxis.label.set_color(AX)
    ax.set_title(title, color="white", fontsize=10, fontweight="bold", pad=6)
    ax.set_xlabel(xl, fontsize=8); ax.set_ylabel(yl, fontsize=8)
    ax.grid(True, color=GD, lw=0.5, ls="--", alpha=0.8)

# ── 第一行 ───────────────────────────────────────────────────────────────────
ax_pos = fig.add_subplot(gs[0, 0]); style(ax_pos, "【A】位置轨迹 Position",   "时间 s", "位置 rad")
ax_vel = fig.add_subplot(gs[0, 1]); style(ax_vel, "【A】速度剖面 Velocity",   "时间 s", "速度 rad/s")
ax_acc = fig.add_subplot(gs[0, 2]); style(ax_acc, "【D】加速度/Jerk 对比",    "时间 s", "加速度 rad/s²")

for (lbl, clr, _, _, _), (t, pos, vel, acc, jrk) in zip(scenarios, profiles):
    kw = dict(color=clr, lw=2.0, label=lbl.replace("\n", " "))
    ax_pos.plot(t, pos, **kw); ax_vel.plot(t, vel, **kw); ax_acc.plot(t, acc, **kw)

for ax in [ax_pos, ax_vel, ax_acc]:
    leg = ax.legend(fontsize=7, facecolor="#0a0a18", edgecolor="#3a3a5a", labelcolor=AX)

# 在速度图上标注峰值
for (lbl, clr, _, _, _), (t, pos, vel, acc, jrk) in zip(scenarios, profiles):
    pk = np.max(np.abs(vel)); idx = np.argmax(np.abs(vel))
    ax_vel.annotate(f"{pk:.3f}", (t[idx], vel[idx]),
                    textcoords="offset points", xytext=(4, 6),
                    fontsize=7, color=clr, fontweight="bold")

# ── 第二行 ───────────────────────────────────────────────────────────────────
ax_bv  = fig.add_subplot(gs[1, 0]); style(ax_bv,  "峰值速度对比 Peak Velocity",  "场景", "峰值速度 rad/s")
ax_bd  = fig.add_subplot(gs[1, 1]); style(ax_bd,  "完成耗时对比 Duration",        "场景", "耗时 s")
ax_cmp = fig.add_subplot(gs[1, 2]); style(ax_cmp, "梯形 vs 五次多项式 速度剖面", "时间 s", "速度 rad/s")

clrs = [s[1] for s in scenarios]
xlbls = [s[0].replace("\n", "\n") for s in scenarios]
xv = np.arange(len(scenarios))
peak_vels = [np.max(np.abs(p[2])) for p in profiles]
durs      = [p[0][-1] for p in profiles]

b1 = ax_bv.bar(xv, peak_vels, color=clrs, width=0.55, edgecolor="#1a1a2e", lw=0.8)
ax_bv.set_xticks(xv); ax_bv.set_xticklabels(xlbls, fontsize=7, color=AX)
for b, v in zip(b1, peak_vels):
    ax_bv.text(b.get_x()+b.get_width()/2, v+0.003, f"{v:.3f}", ha="center", va="bottom", fontsize=7.5, color="white", fontweight="bold")

b2 = ax_bd.bar(xv, durs, color=clrs, width=0.55, edgecolor="#1a1a2e", lw=0.8)
ax_bd.set_xticks(xv); ax_bd.set_xticklabels(xlbls, fontsize=7, color=AX)
for b, v in zip(b2, durs):
    ax_bd.text(b.get_x()+b.get_width()/2, v+0.03, f"{v:.2f}s", ha="center", va="bottom", fontsize=7.5, color="white", fontweight="bold")

t_tr, _, vtr, _, _ = make_profile(0.10, 0.08, None)
t_qu, _, vqu, _, _ = make_profile(0.10, 0.08, 1.0)
ax_cmp.plot(t_tr, vtr, "#e74c3c", lw=2.2, label="梯形剖面 Trapezoidal")
ax_cmp.plot(t_qu, vqu, "#9b59b6", lw=2.2, ls="--", label="五次多项式 Quintic (jerk=1.0)")
ax_cmp.fill_between(t_tr, vtr, alpha=0.12, color="#e74c3c")
ax_cmp.fill_between(t_qu, vqu, alpha=0.12, color="#9b59b6")
ax_cmp.legend(fontsize=8, facecolor="#0a0a18", edgecolor="#3a3a5a", labelcolor=AX)
ax_cmp.text(0.55, 0.92, "同样 v_max=0.10, a_max=0.08\nQuintic 尾端更平滑",
            transform=ax_cmp.transAxes, fontsize=7.5, color="#cccccc",
            ha="center", bbox=dict(facecolor="#0a0a18", edgecolor="#3a3a5a", alpha=0.8, boxstyle="round,pad=0.3"))

# ── 第三行 ───────────────────────────────────────────────────────────────────
ax_g = fig.add_subplot(gs[2, 0]); style(ax_g, "【C】夹爪缝隙 Gripper Gap", "Manner 夹持词", "缝隙 mm")
ax_s = fig.add_subplot(gs[2, 1]); style(ax_s, "【B】刚度→接触力响应 Stiffness", "时间 s", "接触力 N (示意)")
ax_t = fig.add_subplot(gs[2, 2]); ax_t.axis("off"); ax_t.set_facecolor(BG)

# Gripper
gx = np.arange(len(gripper_scenes))
bg = ax_g.bar(gx, gripper_gaps, color=[s[1] for s in gripper_scenes],
              width=0.58, edgecolor="#0a0a18", lw=0.8)
ax_g.set_xticks(gx); ax_g.set_xticklabels([s[0] for s in gripper_scenes], fontsize=8, color=AX)
ax_g.axhline(GRIPPER_MAX*2*1000, color="white", lw=1.0, ls=":", alpha=0.5, label="最大开口 80mm")
ax_g.legend(fontsize=8, facecolor="#0a0a18", edgecolor="#3a3a5a", labelcolor=AX)
for b, v in zip(bg, gripper_gaps):
    ax_g.text(b.get_x()+b.get_width()/2, v+0.5, f"{v:.0f}mm", ha="center", va="bottom", fontsize=8.5, color="white", fontweight="bold")

# Stiffness contact force
for (lbl, clr, kp, _) in stiff_scenes:
    F = kp * x_intrusion
    ax_s.plot(t_contact, F, color=clr, lw=2.0, label=lbl.replace("\n", " "))
    ax_s.fill_between(t_contact, F, alpha=0.10, color=clr)
ax_s.legend(fontsize=7.5, facecolor="#0a0a18", edgecolor="#3a3a5a", labelcolor=AX)
ax_s.text(0.50, 0.88, "kp↑ → 同形变产生更大接触力\n轻轻接触时应降低 kp",
          transform=ax_s.transAxes, fontsize=7.5, color="#cccccc", ha="center",
          bbox=dict(facecolor="#0a0a18", edgecolor="#3a3a5a", alpha=0.8, boxstyle="round,pad=0.3"))

# Summary
ax_t.set_title("四维约束全景  MannerCap API", color="white", fontsize=10, fontweight="bold", pad=6)
rows = [
    ["维度",   "底层方法",                        "高层API",                      "Manner词 → 参数"],
    ["A 速度", "move_to_joints_profiled()",       "goto_pose_with_profile()",     "缓缓→v_max=0.03  迅速→0.25"],
    ["B 刚度", "set_joint_stiffness(kp)",         "set_impedance_stiffness()",    "轻轻→kp=400  用力→kp=1500"],
    ["C 夹持", "close_gripper_partial()",         "close_gripper_partial()",      "虚握→force=0.1  紧握→0.95"],
    ["D 平稳", "move_to_joints_profiled(jerk=.)", "goto_pose_with_profile(jerk)", "平稳→jerk_limit=0.5~1.0"],
]
cxs = [0.01, 0.20, 0.43, 0.66]
row_bg = ["#253050", "#192038", "#192038", "#192038", "#192038"]
txt_colors = [["#f0c040","#f0c040","#f0c040","#f0c040"],
              ["#7ec8e3","#a0e0a0","#f0a060","#e0e0e0"],
              ["#7ec8e3","#a0e0a0","#f0a060","#e0e0e0"],
              ["#7ec8e3","#a0e0a0","#f0a060","#e0e0e0"],
              ["#7ec8e3","#a0e0a0","#f0a060","#e0e0e0"]]
for ri, row in enumerate(rows):
    by = 0.90 - ri * 0.167
    rct = plt.Rectangle((0.0, by-0.06), 1.0, 0.15,
                         transform=ax_t.transAxes, facecolor=row_bg[ri],
                         edgecolor="#2a3555", lw=0.7, clip_on=False)
    ax_t.add_patch(rct)
    for ci, (cell, cx) in enumerate(zip(row, cxs)):
        fw = "bold" if ri == 0 else "normal"
        fs = 7.0
        ax_t.text(cx, by+0.01, cell, transform=ax_t.transAxes,
                  fontsize=fs, color=txt_colors[ri][ci], fontweight=fw, va="center")

out = "/workdata/stage_cap_privileged_data_generation_repro_20260629/robosuite/stagecap_robosuite_libero_repro_20260714/new/manner_trajectory_verification.png"
fig.savefig(out, dpi=140, bbox_inches="tight", facecolor=fig.get_facecolor())
print(f"[OK] Saved: {out}")

print("\n═══ Manner A: 轨迹统计 ═══")
for (lbl, _, vm, am, jl), (t, pos, vel, acc, jrk) in zip(scenarios, profiles):
    pv = np.max(np.abs(vel)); pa = np.max(np.abs(acc)); pj = np.max(np.abs(jrk))
    print(f"  {lbl.replace(chr(10),' '):28s}  峰值速度={pv:.4f} rad/s  峰值加速度={pa:.4f}  峰值Jerk={pj:.3f}  耗时={t[-1]:.2f}s")

print("\n═══ Manner C: 夹爪缝隙 ═══")
for (lbl, _, f), g in zip(gripper_scenes, gripper_gaps):
    print(f"  {lbl.replace(chr(10),' '):20s}  force={f:.2f}  缝隙={g:.1f}mm  fraction={1-f:.2f}")

print(f"\n速度比(最快/最慢) = {max(peak_vels)/min(peak_vels):.1f}x")
print(f"耗时比(最慢/最快) = {max(durs)/min(durs):.1f}x")
