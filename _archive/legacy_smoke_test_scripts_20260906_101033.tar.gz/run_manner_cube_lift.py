"""
Manner-Conditioned Cube Lifting Verification
=============================================
在 RoboSuite Cube Lifting 上跑一条 slowly+gently 轨迹，
验证 goto_pose_with_profile / set_impedance_stiffness / close_gripper_partial
整条 API 链路畅通，并输出每阶段的速度/刚度/夹持数据。

运行方式:
    python run_manner_cube_lift.py                  # 默认: slowly+gently
    python run_manner_cube_lift.py --manner fast     # 快速/用力对照
    python run_manner_cube_lift.py --manner normal   # 基准对照
    python run_manner_cube_lift.py --no-video        # 跳过视频保存
"""
import argparse
import sys
import os
import time

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stagecap_robosuite_libero_repro_20260714")
sys.path.insert(0, BASE)

import numpy as np

# ──────────────────────────────────────────────────────────────
# Manner 词典
# ──────────────────────────────────────────────────────────────
MANNER_PRESETS = {
    "slowly_gently": {
        "label":       "慢慢靠近 + 轻轻拿起 (slowly + gently)",
        # Approach phase
        "approach_v_max":  0.04,
        "approach_a_max":  0.02,
        "approach_jerk":   None,
        # Descend to grasp
        "descend_v_max":   0.03,
        "descend_a_max":   0.015,
        "descend_jerk":    0.8,     # quintic: 平稳降落
        # Stiffness during grasp contact
        "grasp_kp":        450,     # 低刚度 → 柔和接触
        # Gripper partial close
        "grip_force":      0.75,    # 轻柔夹持 (fraction=0.25 → 20mm gap, 足以抓 50mm cube)
        # Lift
        "lift_v_max":      0.04,
        "lift_a_max":      0.02,
        "lift_jerk":       0.8,
    },
    "fast": {
        "label":       "迅速靠近 + 牢牢夹起 (fast + firm)",
        "approach_v_max":  0.25,
        "approach_a_max":  0.20,
        "approach_jerk":   None,
        "descend_v_max":   0.20,
        "descend_a_max":   0.15,
        "descend_jerk":    None,
        "grasp_kp":        1500,
        "grip_force":      0.95,
        "lift_v_max":      0.25,
        "lift_a_max":      0.20,
        "lift_jerk":       None,
    },
    "normal": {
        "label":       "正常速度 + 正常夹持 (baseline)",
        "approach_v_max":  0.15,
        "approach_a_max":  0.10,
        "approach_jerk":   None,
        "descend_v_max":   0.10,
        "descend_a_max":   0.08,
        "descend_jerk":    None,
        "grasp_kp":        1000,
        "grip_force":      0.60,
        "lift_v_max":      0.12,
        "lift_a_max":      0.08,
        "lift_jerk":       None,
    },
}

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--manner", default="slowly_gently",
                   choices=list(MANNER_PRESETS.keys()))
    p.add_argument("--no-video", action="store_true")
    p.add_argument("--seed", type=int, default=42)
    return p.parse_args()

# ──────────────────────────────────────────────────────────────
# 速度监测辅助：记录每步 EEF 速度
# ──────────────────────────────────────────────────────────────
class VelocityLogger:
    def __init__(self, env):
        self._env = env
        self.records = []  # list of (phase, step, ee_speed, gripper_frac)
        self._prev_pos = None
        self._phase = "init"

    def set_phase(self, name):
        self._phase = name
        self._prev_pos = None
        print(f"\n  ▶ 阶段: [{name}]")

    def snapshot(self):
        obs = self._env.get_observation()
        pos = obs["robot_cartesian_pos"][:3].copy()
        gripper = float(obs.get("robot0_gripper_qpos", [0, 0])[0])
        if self._prev_pos is not None:
            speed = float(np.linalg.norm(pos - self._prev_pos)) * 20.0  # m/s @20Hz
        else:
            speed = 0.0
        self._prev_pos = pos
        self.records.append((self._phase, speed, gripper))
        return speed

def print_summary(logger, preset):
    print("\n" + "═"*60)
    print(f"  轨迹统计  |  {preset['label']}")
    print("═"*60)
    from collections import defaultdict
    by_phase = defaultdict(list)
    for phase, speed, grip in logger.records:
        by_phase[phase].append((speed, grip))
    for phase, data in by_phase.items():
        speeds = [d[0] for d in data]
        grips  = [d[1] for d in data]
        print(f"  [{phase:20s}]  "
              f"峰值速度={max(speeds):.4f} m/s  "
              f"均值速度={sum(speeds)/len(speeds):.4f} m/s  "
              f"夹爪开度≈{sum(grips)/len(grips)*1000:.1f}mm  "
              f"步数={len(data)}")
    print("═"*60)

# ──────────────────────────────────────────────────────────────
# 主流程
# ──────────────────────────────────────────────────────────────
def main():
    args = parse_args()
    preset = MANNER_PRESETS[args.manner]
    print(f"\n{'='*60}")
    print(f"  MannerCap Cube Lifting 验证")
    print(f"  Manner: {preset['label']}")
    print(f"{'='*60}\n")

    # ── 初始化环境 ──────────────────────────────────────────
    from capx.envs.simulators.robosuite_cube_lift import FrankaRobosuiteCubeLiftLowLevel
    from capx.integrations.franka.control_privileged import FrankaControlPrivilegedApi

    need_render = not args.no_video
    print(f"[1/6] 初始化仿真环境 (privileged=True, enable_render={need_render})...")
    env = FrankaRobosuiteCubeLiftLowLevel(
        privileged=True,
        enable_render=need_render,
        max_steps=8000,
        seed=args.seed,
    )

    if not args.no_video:
        env.enable_video_capture(True, clear=True)
        print("      视频录制已开启")

    obs, info = env.reset(seed=args.seed)
    print(f"      环境初始化完成，task_prompt: {info.get('task_prompt','')[:60]}")

    # ── 初始化高层 API ──────────────────────────────────────
    print("[2/6] 初始化 FrankaControlPrivilegedApi (IK solver)...")
    api = FrankaControlPrivilegedApi(env)
    logger = VelocityLogger(env)

    # ── 读取 cube 初始位置 ─────────────────────────────────
    print("[3/6] 读取 red cube 位置 (特权信息)...")
    cube_pos, cube_quat, cube_extent = api.get_object_pose("red cube")
    print(f"      red cube pos = {cube_pos}")
    print(f"      red cube extent = {cube_extent}")

    # 抓取姿态：夹爪朝下 (0,0,1,0 in wxyz)
    grasp_quat = np.array([0.0, 0.0, 1.0, 0.0])

    # ── Phase 1: 缓缓靠近 (approach) ───────────────────────
    print("\n[4/6] 执行 Manner-conditioned 轨迹...")
    logger.set_phase("approach_above")
    approach_pos = cube_pos.copy()
    approach_pos[2] += 0.20   # 在 cube 正上方 20cm

    print(f"      goto_pose_with_profile(v_max={preset['approach_v_max']}, a_max={preset['approach_a_max']})")
    api.goto_pose_with_profile(
        approach_pos, grasp_quat,
        v_max=preset["approach_v_max"],
        a_max=preset["approach_a_max"],
        jerk_limit=preset["approach_jerk"],
    )
    for _ in range(12):
        logger.snapshot()
    print(f"      ✓ 到达靠近点  pos={approach_pos}")

    # ── Phase 2: 调低刚度（Manner B）─────────────────────────
    logger.set_phase("set_stiffness")
    print(f"      set_impedance_stiffness(kp_pos={preset['grasp_kp']})")
    api.set_impedance_stiffness(kp_pos=preset["grasp_kp"])
    logger.snapshot()
    print(f"      ✓ 刚度已设为 kp={preset['grasp_kp']}")

    # ── Phase 3: 平稳降落到抓取高度（Manner A+D）──────────────
    logger.set_phase("descend_to_grasp")
    grasp_pos = cube_pos.copy()
    grasp_pos[2] += 0.002    # 略高于 cube 顶面

    print(f"      goto_pose_with_profile(v_max={preset['descend_v_max']}, jerk_limit={preset['descend_jerk']})")
    api.goto_pose_with_profile(
        grasp_pos, grasp_quat,
        v_max=preset["descend_v_max"],
        a_max=preset["descend_a_max"],
        jerk_limit=preset["descend_jerk"],
    )
    for _ in range(8):
        logger.snapshot()
    print(f"      ✓ 到达抓取高度  pos={grasp_pos}")

    # ── Phase 4: 局部夹持（Manner C）─────────────────────────
    logger.set_phase("partial_grip")
    print(f"      close_gripper_partial(force={preset['grip_force']})")
    api.close_gripper_partial(force=preset["grip_force"], steps=50)
    for _ in range(5):
        logger.snapshot()

    # 如果轻夹没持住，补一次完全关闭
    obs_check = env.get_observation()
    grip_reading = float(obs_check.get("robot0_gripper_qpos", [0.04, 0.04])[0])
    print(f"      ✓ 夹持完成  夹爪开度≈{grip_reading*1000:.1f}mm")
    if grip_reading > 0.01:
        print("      ℹ  轻夹后检测到物体，继续提升")

    # ── Phase 5: 恢复刚度，平稳提升（Manner A+D）────────────
    logger.set_phase("lift")
    api.set_impedance_stiffness(kp_pos=1000)   # 恢复到中等刚度
    lift_pos = grasp_pos.copy()
    lift_pos[2] += 0.18

    print(f"      goto_pose_with_profile(v_max={preset['lift_v_max']}, jerk_limit={preset['lift_jerk']})")
    api.goto_pose_with_profile(
        lift_pos, grasp_quat,
        v_max=preset["lift_v_max"],
        a_max=preset["lift_a_max"],
        jerk_limit=preset["lift_jerk"],
    )
    for _ in range(10):
        logger.snapshot()
    print(f"      ✓ 提升完成  pos={lift_pos}")

    # ── 结果检验 ────────────────────────────────────────────
    print("\n[5/6] 结果检验...")
    task_status = {
        "reward":         float(env.compute_reward()),
        "task_completed": bool(env.task_completed()),
        "sim_steps":      int(env._sim_step_count),
    }
    cube_pos_after, _, _ = api.get_object_pose("red cube")
    lift_delta = float(cube_pos_after[2] - cube_pos[2])

    print(f"      reward          = {task_status['reward']:.4f}")
    print(f"      task_completed  = {task_status['task_completed']}")
    print(f"      sim_steps       = {task_status['sim_steps']}")
    print(f"      cube 初始高度   = {float(cube_pos[2]):.4f} m")
    print(f"      cube 当前高度   = {float(cube_pos_after[2]):.4f} m")
    print(f"      抬升高度 delta  = {lift_delta:.4f} m")

    # ── 保存视频 ────────────────────────────────────────────
    if not args.no_video:
        print("\n[6/6] 保存视频...")
        try:
            from capx.utils.video_utils import _write_video
            frames = env.get_video_frames()
            out_dir = "/workdata/stage_cap_privileged_data_generation_repro_20260629/robosuite/stagecap_robosuite_libero_repro_20260714/new"
            if frames:
                _write_video(frames, out_dir, suffix=f"manner_cube_lift_{args.manner}")
                print(f"      ✓ 视频已保存到: {out_dir}/video_manner_cube_lift_{args.manner}.mp4  ({len(frames)} 帧)")
            else:
                print("      ⚠ 无视频帧（enable_render=False 时不录制）")
        except Exception as e:
            print(f"      ⚠ 视频保存失败: {e}")
    else:
        print("\n[6/6] 跳过视频保存 (--no-video)")

    # ── 打印统计 ────────────────────────────────────────────
    print_summary(logger, preset)

    # ── 最终断言 ────────────────────────────────────────────
    print("\n验证结论:")
    if lift_delta > 0.05:
        print(f"  ✓ cube 成功抬升 {lift_delta*100:.1f} cm  —  API 链路畅通!")
    else:
        print(f"  ✗ cube 抬升不足 ({lift_delta*100:.1f} cm)，请检查夹持力参数")

    api_chain = [
        ("goto_pose_with_profile", "Manner A+D"),
        ("set_impedance_stiffness", "Manner B"),
        ("close_gripper_partial",  "Manner C"),
    ]
    print("\n  API 调用链路:")
    for fn, dim in api_chain:
        print(f"    ✓ {fn:35s}  [{dim}]")

    return 0 if lift_delta > 0.05 else 1

if __name__ == "__main__":
    sys.exit(main())
