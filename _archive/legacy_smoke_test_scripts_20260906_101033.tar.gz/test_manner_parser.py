"""
测试 LLMMannerParser：用自然语言描述生成 MannerSpec，
并打印解析结果对比。
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/stagecap_robosuite_libero_repro_20260714")

os.environ["AIHUBMIX_API_KEY"] = "sk-SNyQ8MgTOro95Ph29dB356B0708646F894EcF4290f0606E9"

from capx.llm.manner_parser import LLMMannerParser

TEST_CASES = [
    # (描述,  期望类型)
    ("像捧着装满水的玻璃杯那样，轻轻把方块放到托盘上",        "slow+soft"),
    ("迅速抓起来，越快越好",                               "fast"),
    ("小心翼翼，像在排除炸弹",                             "very_careful"),
    ("用力把它压进去，确保固定住",                          "firm"),
    ("先快速靠近，到最后5cm时慢慢接触",                     "fast_then_slow"),
    ("正常操作就行",                                       "normal"),
    ("像哄婴儿睡觉一样，极其轻柔缓慢",                      "ultra_gentle"),
    ("Place the block firmly onto the platform",           "firm_en"),
    ("慢慢靠近然后轻轻夹住",                               "slowly_gently"),
]

parser = LLMMannerParser()

print("=" * 70)
print("  LLMMannerParser 测试结果  (Gemini 3.7 Flash)")
print("=" * 70)

results = []
for desc, expected_type in TEST_CASES:
    try:
        spec, reasoning = parser.parse_with_reasoning(desc)
        print(f"\n[{expected_type}]")
        print(f"  输入: {desc}")
        print(f"  推理: {reasoning}")
        print(f"  label: {spec.label}")
        print(f"  Dim A vel  : max={spec.max_joint_vel}  min={spec.min_joint_vel}")
        print(f"  Dim B kp   : max={spec.kp_max}   min={spec.kp_min}")
        print(f"  Dim C grip : max={spec.grip_fraction_max}  min={spec.grip_fraction_min}")
        print(f"  Dim D jerk : max={spec.max_jerk}")
        has_constraints = spec.has_any_constraint()
        results.append((expected_type, True))
    except Exception as e:
        print(f"\n[{expected_type}] ERROR: {e}")
        results.append((expected_type, False))

print("\n" + "=" * 70)
passed = sum(1 for _, ok in results if ok)
print(f"  {passed}/{len(results)} 解析成功")

# ── 追加: 验证 compose 后可直接传给 MannerValidator ──
print("\n── 与 MannerValidator 联动测试 ──")
from capx.envs.manner_validator import MannerValidator, MannerStepSnapshot
import numpy as np

spec_gentle = parser.parse("像捧着豆腐一样轻轻拿起")
print(f"  spec_gentle: {spec_gentle}")

# mock telemetry: 慢速+低kp+轻握
snaps = [
    MannerStepSnapshot(
        t=i*0.05, phase="move",
        joint_vel=np.ones(7)*0.03,
        joint_acc=np.zeros(7),
        kp=450.0,
        gripper_fraction=0.22,
        gripper_qpos=np.array([0.008, -0.008]),
        cfrc_norm=0.0,
    )
    for i in range(40)
] + [
    MannerStepSnapshot(
        t=40*0.05+i*0.05, phase="grip",
        joint_vel=np.zeros(7),
        joint_acc=np.zeros(7),
        kp=450.0,
        gripper_fraction=0.22,
        gripper_qpos=np.array([0.008, -0.008]),
        cfrc_norm=0.1,
    )
    for i in range(20)
]

evidence = MannerValidator().validate(snaps, spec_gentle, stage_id="test_llm_parse")
print(f"  ValidationResult: {evidence.status}")
print(f"  Rationale: {evidence.rationale[:120]}")
