"""
MannerCap — Manner 验证器集成测试
对三种 manner preset 各跑一条轨迹并用 MannerValidator 验证结果。

运行（需在 stagecap_robosuite_libero_repro_20260714/ 目录，且 IK 服务已启动）：
    MUJOCO_GL=egl /workdata/cap-x/.venv/bin/python3 ../test_manner_validator.py
"""
from __future__ import annotations
import sys, os, argparse
os.environ.setdefault("MUJOCO_GL", "egl")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/stagecap_robosuite_libero_repro_20260714")

import numpy as np

from capx.envs.simulators.robosuite_cube_lift import FrankaRobosuiteCubeLiftLowLevel
from capx.integrations.franka.control_privileged import FrankaControlPrivilegedApi
from capx.envs.manner_validator import (
    MannerValidator, MANNER_PRESETS, compose_manner_spec, validate_manner_stage,
)

# ── Manner presets (同 run_manner_cube_lift.py) ──
EXEC_PRESETS: dict[str, dict] = {
    "slowly_gently": dict(
        approach_v_max=0.04, approach_a_max=0.02, approach_jerk=None,
        descend_v_max=0.03,  descend_a_max=0.10,  descend_jerk=0.8,
        grasp_kp=450,        grip_force=0.75,
        lift_v_max=0.04,     lift_a_max=0.10,     lift_jerk=0.8,
    ),
    "normal": dict(
        approach_v_max=0.12, approach_a_max=0.15, approach_jerk=None,
        descend_v_max=0.10,  descend_a_max=0.15,  descend_jerk=None,
        grasp_kp=1000,       grip_force=0.88,
        lift_v_max=0.12,     lift_a_max=0.15,     lift_jerk=None,
    ),
    "fast": dict(
        approach_v_max=0.30, approach_a_max=0.50, approach_jerk=None,
        descend_v_max=0.25,  descend_a_max=0.50,  descend_jerk=None,
        grasp_kp=1500,       grip_force=1.00,
        lift_v_max=0.30,     lift_a_max=0.50,     lift_jerk=None,
    ),
}

# ── MannerSpec 与各 preset 的期望对应 ──
SPECS: dict[str, str | tuple] = {
    "slowly_gently": ("slowly", "gently"),
    "normal":        "normal",
    "fast":          "fast",
}

GRASP_QUAT = np.array([0.0, 1.0, 0.0, 0.0])  # wxyz, top-down


def run_manner(manner_name: str, seed: int = 42) -> dict:
    """Execute one manner trajectory and return validation results."""
    preset  = EXEC_PRESETS[manner_name]
    spec_id = SPECS[manner_name]

    if isinstance(spec_id, tuple):
        spec = compose_manner_spec(*spec_id)
    else:
        spec = MANNER_PRESETS[spec_id]

    print(f"\n{'='*62}")
    print(f"  Manner: {manner_name}  |  spec: {spec.label!r}")
    print(f"  constraints: max_vel={spec.max_joint_vel}  kp_max={spec.kp_max}  "
          f"grip_max={spec.grip_fraction_max}  max_jerk={spec.max_jerk}")
    print(f"{'='*62}")

    # ── init env ──
    env = FrankaRobosuiteCubeLiftLowLevel(
        privileged=True, enable_render=False, max_steps=8000, seed=seed
    )
    obs, info = env.reset(seed=seed)
    api = FrankaControlPrivilegedApi(env)

    obs_dict = env.get_observation()
    cube_pos = obs_dict["cube_poses"]["primary"][0:3]  # first 3 = xyz
    approach_pos = cube_pos + np.array([0.0, 0.0, 0.20])
    grasp_pos    = cube_pos + np.array([0.0, 0.0, 0.002])
    lift_pos     = cube_pos + np.array([0.0, 0.0, 0.18])

    # ── start recording ──
    env.begin_manner_recording(clear=True)

    # Phase 1: approach
    env._manner_phase = "move"
    api.goto_pose_with_profile(
        approach_pos, GRASP_QUAT,
        v_max=preset["approach_v_max"], a_max=preset["approach_a_max"],
        jerk_limit=preset["approach_jerk"],
    )

    # Phase 2: set stiffness
    api.set_impedance_stiffness(kp_pos=preset["grasp_kp"])

    # Phase 3: descend
    api.goto_pose_with_profile(
        grasp_pos, GRASP_QUAT,
        v_max=preset["descend_v_max"], a_max=preset["descend_a_max"],
        jerk_limit=preset["descend_jerk"],
    )

    # Phase 4: grasp
    api.close_gripper_partial(force=preset["grip_force"])

    # Phase 5: lift
    api.goto_pose_with_profile(
        lift_pos, GRASP_QUAT,
        v_max=preset["lift_v_max"], a_max=preset["lift_a_max"],
        jerk_limit=preset["lift_jerk"],
    )

    env.end_manner_recording()
    telemetry = env.get_manner_telemetry()

    # ── validate ──
    evidence = MannerValidator().validate(telemetry, spec, stage_id=f"cube_lift_{manner_name}")

    # ── print results ──
    print(f"\n[Telemetry]  n_steps={len(telemetry)}")
    if telemetry:
        vel_norms = np.array([np.linalg.norm(s.joint_vel) for s in telemetry])
        kp_vals   = np.array([s.kp for s in telemetry])
        frac_vals = np.array([s.gripper_fraction for s in telemetry])
        by_phase = {}
        for s in telemetry:
            by_phase.setdefault(s.phase, []).append(np.linalg.norm(s.joint_vel))
        print(f"  Peak joint vel : {vel_norms.max():.4f} rad/s")
        print(f"  Min kp recorded: {kp_vals.min():.0f}")
        print(f"  Min grip frac  : {frac_vals.min():.3f}")
        for ph, vels in sorted(by_phase.items()):
            print(f"  phase '{ph}': {len(vels)} steps, peak_vel={max(vels):.4f}")

    print(f"\n[Validation] status = {evidence.status}")
    print(f"  rationale: {evidence.rationale[:300]}")
    if evidence.repair_hint:
        print(f"  repair: {evidence.repair_hint}")
    print("\n  Dimension log:")
    for line in evidence.log_evidence:
        print(f"    {line}")

    return {
        "manner": manner_name,
        "n_steps": len(telemetry),
        "status": str(evidence.status),
        "passed": evidence.status.value == "satisfied",
        "geometry": evidence.geometry_evidence,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manner", choices=list(EXEC_PRESETS.keys()), default=None,
                        help="Which manner to test (default: all three)")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    manners = [args.manner] if args.manner else list(EXEC_PRESETS.keys())

    all_results = []
    for m in manners:
        r = run_manner(m, seed=args.seed)
        all_results.append(r)

    print("\n" + "="*62)
    print("  MANNER VALIDATOR — SUMMARY")
    print("="*62)
    for r in all_results:
        geo = r["geometry"]
        icon = "✓" if r["passed"] else "✗"
        print(f"  {icon} [{r['manner']:20s}]  status={r['status']:15s}  "
              f"steps={r['n_steps']:4d}  "
              f"peak_vel={geo.get('velocity',{}).get('peak_rad_s', 0):.4f}  "
              f"min_kp={geo.get('stiffness',{}).get('min_kp', 0):.0f}  "
              f"min_frac={geo.get('gripper',{}).get('min_fraction', 1.0):.3f}")

    passed = sum(1 for r in all_results if r["passed"])
    print(f"\n  {passed}/{len(all_results)} manner presets passed constraints.")
    return 0 if passed == len(all_results) else 1


if __name__ == "__main__":
    sys.exit(main())
